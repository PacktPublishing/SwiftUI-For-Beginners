import SwiftUI
import SwiftData

@Observable
@MainActor
class DataContainer {
    let modelContainer: ModelContainer
    var context: ModelContext {
        modelContainer.mainContext
    }
    init() {
        let schema = Schema([Cat.self])
        let modelConfiguration = ModelConfiguration(schema: schema)
        do {
            modelContainer = try ModelContainer(for: schema, configurations: [modelConfiguration])
            try context.save()
        } catch {
            fatalError("Could not create ModelContainer: \(error)")
        }
    }
}
