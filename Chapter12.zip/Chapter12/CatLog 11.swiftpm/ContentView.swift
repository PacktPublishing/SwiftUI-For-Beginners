import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            Tab("Cats", systemImage: "cat.fill") {
                CatsView()
            }
            Tab("Map", systemImage: "map") {
                MapView()
            }
        }
    }
}
