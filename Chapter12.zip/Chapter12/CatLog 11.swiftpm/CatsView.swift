import SwiftUI
import SwiftData

struct CatsView: View {
    @State private var showAddCatView = false
    @State private var searchText = ""
    @Query(sort: \Cat.date)
    private var cats: [Cat]
    private var filteredCats: [Cat] {
        if searchText.isEmpty {
            cats
        } else {
            cats.filter { $0.catName.localizedStandardContains(searchText)}
        }
    }
    @Environment(DataContainer.self) private var dataContainer
    var body: some View {
        NavigationSplitView {
            List {
                ForEach(filteredCats) { cat in
                    NavigationLink(destination: CatDetailView(selectedCat: cat)) {
                        CatCellView(cat: cat)
                    }
                }
                .onDelete { indexSet in
                    for index in indexSet {
                        dataContainer.context.delete(cats[index])
                        try? dataContainer.context.save()
                    }
                }
            }
            .searchable(text: $searchText, prompt: "Find a cat")
            .navigationTitle("Cats")
            .toolbar {
                ToolbarItem(placement: .primaryAction) {
                    Button("Add", systemImage: "plus") {
                        showAddCatView = true
                    }
                    .sheet(isPresented: $showAddCatView) {
                        AddNewCatView()
                    }
                }
            }
        } detail: {
            Text("Choose a cat")
                .font(.largeTitle)
        }
        .navigationSplitViewStyle(.balanced)
    }
}

#Preview {
    CatsView()
}
