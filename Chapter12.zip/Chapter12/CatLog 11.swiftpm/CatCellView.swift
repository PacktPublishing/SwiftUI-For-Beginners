import SwiftUI

struct CatCellView: View {
    let cat: Cat
    var body: some View {
        HStack {
            if let catPhoto = cat.photo {
                Image(uiImage: catPhoto)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 90, height: 90)
                    .padding()
            }
            VStack{
                Text(cat.catName)
                    .font(.largeTitle)
                    .frame(maxWidth: .infinity, alignment: .leading)
                Text(cat.catDescription)
                    .lineLimit(2)
                    .font(.title2)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
    }
}

#Preview {
    CatCellView(cat: Cat.sampleCat)
}
