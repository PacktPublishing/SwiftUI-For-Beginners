import SwiftUI

struct CatsView: View {
    @State private var showAddCatView = false
    @State private var cats = Cat.sampleData
    var body: some View {
        NavigationStack {
            List {
                ForEach(cats, id: \.catName) { cat in
                    NavigationLink(destination: CatDetailView(selectedCat: cat)) {
                        CatCellView(cat: cat)
                    }
                }
                .onDelete { indexSet in
                    for index in indexSet {
                        cats.remove(at: index)
                    }
                }
            }
            .navigationTitle("Cats")
            .toolbar {
                ToolbarItem(placement: .primaryAction) {
                    Button("Add", systemImage: "plus") {
                        showAddCatView = true
                    }
                    .sheet(isPresented: $showAddCatView) {
                        AddNewCatView(cats: $cats)
                    }
                }
            }
        }
    }
}

#Preview {
    CatsView()
}
