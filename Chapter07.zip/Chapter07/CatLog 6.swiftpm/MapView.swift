import SwiftUI
import MapKit

struct MapView: View {
    var body: some View {
        NavigationStack {
            Map()
                .navigationTitle("Map")
        }
    }
}

#Preview {
    MapView()
}
