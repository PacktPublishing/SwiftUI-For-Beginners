import SwiftUI

class Cat {
    var date: Date
    var rating: Int
    var catName: String
    var catDescription: String
    var photo: Image?
    var latitude: Double?
    var longitude: Double?
    
    init(rating: Int, catName: String, catDescription: String, photo: Image? = nil, latitude: Double? = nil, longitude: Double? = nil) {
        self.date = Date()
        self.rating = rating
        self.catName = catName
        self.catDescription = catDescription
        self.photo = photo
        self.latitude = latitude
        self.longitude = longitude
    }
}

extension Cat {
    static let sampleCat = sampleData[0]
    static let sampleData = [
        Cat(rating: 5, catName: "Thor", catDescription: "Orange Tabby", photo: Image(systemName: "cat")),
        Cat(rating: 0, catName: "Loki", catDescription: "Tuxedo", photo: Image(systemName: "cat.fill")),
        Cat(rating: 3, catName: "Herman", catDescription: "Gray tabby", photo: Image(systemName: "cat"))
    ]
}
