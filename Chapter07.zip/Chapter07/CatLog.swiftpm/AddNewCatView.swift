import SwiftUI

struct AddNewCatView: View {
    @Binding var cats: [Cat]
    @State private var catName = ""
    @State private var catDescription = ""
    @State private var toggleText = "Get Location"
    @State private var toggleValue = false
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            ScrollView{
                VStack(alignment: .center) {
                    RoundedRectangle(cornerRadius: 8)
                        .frame(width: 252, height: 44)
                        .foregroundStyle(.blue)
                    Toggle(toggleText, isOn: $toggleValue)
                    TextField("Cat name", text: $catName)
                        .font(.largeTitle)
                    TextField("Cat description", text: $catDescription)
                        .font(.title2)
                        .multilineTextAlignment(.leading)
                        .lineLimit(5...Int.max)
                    Image(systemName: "cat.fill")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 300, height: 300)
                        .foregroundStyle(.orange)
                }
                .padding()
            }
                .navigationTitle("Add New Cat")
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) {
                        Button("Cancel", systemImage: "xmark") {
                            dismiss()
                        }
                    }
                    ToolbarItem(placement: .confirmationAction) {
                        Button("Save", systemImage: "checkmark") {
                            let newCat = Cat(rating: 3, catName: catName, catDescription: catDescription, photo: Image(systemName: "cat.fill"))
                            cats.insert(newCat, at: 0)
                            dismiss()
                        }
                        .disabled(catName.isEmpty || catDescription.isEmpty)
                    }
                }
        }
    }
}

#Preview {
    AddNewCatView(cats: .constant(Cat.sampleCatData))
}
