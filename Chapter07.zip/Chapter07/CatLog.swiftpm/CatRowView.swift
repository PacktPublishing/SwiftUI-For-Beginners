import SwiftUI

struct CatRowView: View {
    let cat: Cat
    var body: some View {
        HStack {
            if let catPhoto = cat.photo {
                catPhoto
                .resizable()
                .scaledToFit()
                .frame(width: 90, height: 90)
            }
            VStack {
                Text(cat.catName)
                    .font(.largeTitle)
                    .frame(maxWidth: .infinity, alignment: .leading)
                Text(cat.catDescription)
                    .lineLimit(2, reservesSpace: true)
                    .font(.title2)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
    }
}

#Preview {
    CatRowView(cat: Cat.sampleCat)
}
