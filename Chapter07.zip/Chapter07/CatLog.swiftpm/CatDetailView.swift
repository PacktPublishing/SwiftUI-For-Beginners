import SwiftUI

struct CatDetailView: View {
    var selectedCat: Cat
    var body: some View {
        ScrollView {
            VStack {
                Text(selectedCat.date, style: .date)
                    .font(.title2)
                    .frame(maxWidth: .infinity, alignment: .trailing)
                RoundedRectangle(cornerRadius: 8)
                    .frame(width: 252, height: 44)
                    .foregroundStyle(.blue)
                Text(selectedCat.catDescription)
                    .font(.title2)
                    .frame(maxWidth: .infinity, alignment: .leading)
                Image(systemName: "cat.fill")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 300, height: 300)
                    .foregroundStyle(.orange)
                Image(systemName: "map")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 300, height: 300)
                    .foregroundStyle(.green)
            }
            .padding()
        }
        .navigationTitle(selectedCat.catName)
    }
}

#Preview {
    NavigationStack {
        CatDetailView(selectedCat: Cat.sampleCat)
    }
}
