import SwiftUI

class Cat {
    let date: Date
    let rating: Int
    let catName: String
    let catDescription: String
    let photo: Image?
    let latitude: Double?
    let longitude: Double?
    
    init(rating: Int, catName: String, catDescription: String, photo: Image? = nil, latitude: Double? = nil, longitude: Double? = nil) {
        self.date = Date()
        self.rating = rating
        self.catName = catName
        self.catDescription = catDescription
        self.photo = photo
        self.latitude = latitude
        self.longitude = longitude
    }
}

// Sample data
extension Cat {
    static let sampleCat = sampleCatData[0]
    static let sampleCatData = [
        Cat(rating: 5, catName: "Thor", catDescription: "Orange tabby", photo: Image(systemName: "cat")),
        Cat(rating: 4, catName: "Loki", catDescription: "Tuxedo cat", photo: Image(systemName: "cat.fill")),
        Cat(rating: 3, catName: "Lokitu", catDescription: "Hungry cat", photo: Image(systemName: "cat.fill"))
    ]
}
