import SwiftUI
import CoreLocation

struct AddNewCatView: View {
    @Binding var cats: [Cat]
    @State private var catName = ""
    @State private var catDescription = ""
    @State private var toggleText = "Get Location"
    @State private var toggleValue = false
    @State private var locationManager = CLLocationManager()
    @State private var locationTask: Task<Void, Error>?
    @State private var currentLocation: CLLocation?
    @State private var isShowingLocationNotFound = false
    @State private var locationNotFoundReason = ""
    
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .center) {
                    RoundedRectangle(cornerRadius: 8)
                        .frame(width: 252, height: 44)
                        .foregroundStyle(.blue)
                    Toggle(toggleText, isOn: $toggleValue)
                        .onChange(of: toggleValue) {
                            if toggleValue {
                                toggleText = "Getting location..."
                                fetchUserLocation()
                            } else {
                                currentLocation = nil
                                toggleText = "Get Location"
                                locationTask?.cancel()
                            }
                        }
                        .alert(locationNotFoundReason, isPresented: $isShowingLocationNotFound) {
                            Button("OK") {
                                toggleValue = false
                                isShowingLocationNotFound = false
                            }
                        }
                        .padding()
                    TextField("Cat name", text: $catName)
                        .font(.largeTitle)
                    TextField("Cat description", text: $catDescription, axis: .vertical)
                        .font(.title2)
                        .multilineTextAlignment(.leading)
                        .lineLimit(5...Int.max)
                    Image(systemName: "cat.fill")
                        .resizable()
                        .frame(width: 300, height: 300)
                        .foregroundStyle(.orange)
                }
                .padding()
            }
                .navigationTitle("Add New Cat")
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) {
                        Button("Cancel", systemImage: "xmark") {
                            dismiss()
                        }
                    }
                    ToolbarItem(placement: .confirmationAction) {
                        Button("Save", systemImage: "checkmark") { 
                            let newCat = Cat(rating: 3, catName: catName, catDescription: catDescription, photo: Image(systemName: "cat.fill"), latitude: currentLocation?.coordinate.latitude, longitude: currentLocation?.coordinate.longitude)
                            cats.insert(newCat, at: 0)
                            dismiss()
                        }
                        .disabled(catName.isEmpty || catDescription.isEmpty)
                    }
                }
        }
    }
    
    private func fetchUserLocation() {
        locationManager.requestWhenInUseAuthorization()
        locationTask = Task {
            for try await update in CLLocationUpdate.liveUpdates() {
                if let location = update.location {
                    updateCurrentLocation(location)
                } else if update.authorizationDenied {
                    locationNotFoundReason = "Authorization Denied"
                    isShowingLocationNotFound = true
                } else if update.locationUnavailable {
                    locationNotFoundReason = "Location Unavailable"
                    isShowingLocationNotFound = true
                }
            }
        }
    }
    
    private func updateCurrentLocation(_ location: CLLocation) {
        let interval = location.timestamp.timeIntervalSinceNow
        if abs(interval) < 30 {
            locationTask?.cancel()
            toggleText = "Done"
            let lat = location.coordinate.latitude
            let long = location.coordinate.longitude
            currentLocation = CLLocation(latitude: lat, longitude: long)
        }
    }
}

#Preview {
    AddNewCatView(cats: .constant(Cat.sampleData))
}
