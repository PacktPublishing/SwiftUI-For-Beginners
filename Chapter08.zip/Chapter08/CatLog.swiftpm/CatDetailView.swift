import SwiftUI
import MapKit

struct CatDetailView: View {
    var selectedCat: Cat
    @State private var mapSnapshot: UIImage? = nil
    var body: some View {
        ScrollView {
            VStack {
                Text(selectedCat.date, style: .date)
                    .font(.title2)
                    .frame(maxWidth: .infinity, alignment: .trailing)
                RoundedRectangle(cornerRadius: 8)
                    .frame(width: 252, height: 44)
                    .foregroundStyle(.blue)
                Text(selectedCat.catDescription)
                    .font(.title2)
                    .frame(maxWidth: .infinity, alignment: .leading)
                Image(systemName: "cat.fill")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 300, height: 300)
                    .foregroundStyle(.orange)
                if let mapSnapshot {
                    ZStack {
                        Image(uiImage: mapSnapshot)
                            .resizable()
                            .frame(width: 300, height: 300)
                            .padding()
                        Image(systemName: "cat.fill")
                            .foregroundStyle(.red)
                    }
                }
            }
            .padding()
            .onAppear {
                getMapSnapshot()
            }
        }
        .navigationTitle(selectedCat.catName)
    }
    
    private func getMapSnapshot() {
        guard let lat = selectedCat.latitude, let long = selectedCat.longitude else {
            return
        }
        let options = MKMapSnapshotter.Options()
        options.region = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: lat, longitude: long), span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01))
        options.size = CGSize(width: 300, height: 300)
        options.preferredConfiguration = MKStandardMapConfiguration()
        let snapshotter = MKMapSnapshotter(options: options)
        snapshotter.start { snapshot, error in
            if let snapshot {
                mapSnapshot = snapshot.image
            } else if let error {
                print("snapshot error: \(error.localizedDescription)")
            }
        }
    }
}

#Preview {
    NavigationStack {
        CatDetailView(selectedCat: Cat.sampleCat)
    }
}
