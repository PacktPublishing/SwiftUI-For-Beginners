import SwiftUI
import MapKit

struct MapView: View {
    @State private var cats = Cat.sampleCatData
    @State private var position: MapCameraPosition = .region(MKCoordinateRegion())
    @State private var navTitle = "Map"
    private let locationManager = CLLocationManager()
    @State private var locationTask: Task<Void, Error>?
    @State private var isShowingLocationNotFound = false
    @State private var locationNotFoundReason = ""
    var body: some View {
        NavigationStack {
            Map(position: $position) {
                ForEach(cats, id: \.catName) { cat in
                    if let lat = cat.latitude, let long = cat.longitude {
                        Annotation(cat.catName, coordinate: CLLocationCoordinate2D(latitude: lat, longitude: long)) {
                            NavigationLink(destination: CatDetailView(selectedCat: cat)) {
                                Image(systemName: "cat.fill")
                            }
                            .buttonStyle(.glass)
                            .foregroundStyle(.red)
                        }
                    }
                }
            }
                .navigationTitle(navTitle)
                .onAppear() {
                    fetchUserLocation()
                }
                .alert(locationNotFoundReason, isPresented: $isShowingLocationNotFound) {
                    Button("OK") {
                        navTitle = "Map"
                        isShowingLocationNotFound = false
                    }
                }
        }
    }
    
    private func fetchUserLocation() {
        locationManager.requestWhenInUseAuthorization()
        locationManager.desiredAccuracy = kCLLocationAccuracyKilometer
        navTitle = "Getting location..."
        locationTask = Task {
            for try await update in CLLocationUpdate.liveUpdates() {
                if let location = update.location {
                    updateMapWithLocation(location)
                } else if update.authorizationDenied {
                    locationNotFoundReason = "Authorization Denied"
                    isShowingLocationNotFound = true
                } else if update.locationUnavailable {
                    locationNotFoundReason = "Location Unavailable"
                    isShowingLocationNotFound = true
                }
            }
        }
    }
    
    private func updateMapWithLocation(_ location: CLLocation) {
        let interval = location.timestamp.timeIntervalSinceNow
        if abs(interval) < 30 {
            locationTask?.cancel()
            let lat = location.coordinate.latitude
            let long = location.coordinate.longitude
            cats.append(Cat(rating: 4, catName: "Graymalkin", catDescription: "Gray tabby", photo: Image(systemName: "cat.fill"), latitude: lat, longitude: long))
            navTitle = "Map"
            let currentUserLocatiomRegion = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: lat, longitude: long), span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01))
            position = .region(currentUserLocatiomRegion)
        }
    }
}

#Preview {
    MapView()
}
