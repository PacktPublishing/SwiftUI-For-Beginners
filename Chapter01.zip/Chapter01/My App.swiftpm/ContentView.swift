import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Image(systemName: "cat.fill")
                .imageScale(.large)
                .foregroundColor(.accentColor)
            Text("CatLog")
        }
    }
}
