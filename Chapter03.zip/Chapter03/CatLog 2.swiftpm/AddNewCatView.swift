import SwiftUI

struct AddNewCatView: View {
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            Text("Add New Cat View")
                .navigationTitle("Add New Cat")
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) {
                        Button("Cancel", systemImage: "xmark") {
                            dismiss()
                        }
                    }
                    ToolbarItem(placement: .confirmationAction) {
                        Button("Save", systemImage: "checkmark") { 
                        
                        }
                    }
                }
        }
    }
}

#Preview {
    AddNewCatView()
}
