import SwiftUI

struct CatsView: View {
    @State private var showAddCatView = false
    var body: some View {
        NavigationStack {
            List {
                Text("Thor")
                Text("Loki")
                Text("Herman")
            }
            .navigationTitle("Cats")
            .toolbar {
                ToolbarItem(placement: .primaryAction) {
                    Button("Add", systemImage: "plus") {
                        showAddCatView = true
                    }
                    .sheet(isPresented: $showAddCatView) {
                        AddNewCatView()
                    }
                }
            }
        }
    }
}

#Preview {
    CatsView()
}
