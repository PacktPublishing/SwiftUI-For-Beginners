import SwiftUI

struct CatsView: View {
    @State private var showAddCatView = false
    @State private var cats = Cat.sampleData
    var body: some View {
        NavigationStack {
            List {
                ForEach(cats, id: \.catName) { cat in
                    NavigationLink(destination: CatDetailView()) {
                        CatCellView(cat: cat)
                    }
                }
            }
            .navigationTitle("Cats")
            .toolbar {
                ToolbarItem(placement: .primaryAction) {
                    Button("Add", systemImage: "plus") {
                        showAddCatView = true
                    }
                    .sheet(isPresented: $showAddCatView) {
                        AddNewCatView()
                    }
                }
            }
        }
    }
}

#Preview {
    CatsView()
}
