import SwiftUI

struct CatDetailView: View {
    var body: some View {
        ScrollView {
            VStack {
                Text("8 April 2026")
                    .font(.title2)
                    .frame(maxWidth: .infinity, alignment: .trailing)
                RoundedRectangle(cornerRadius: 8)
                    .frame(width: 252, height: 44)
                    .foregroundStyle(.blue)
                Text("everybody wants to be a cat because a cats the only cat who knows where its at")
                    .font(.title2)
                    .frame(maxWidth: .infinity, alignment: .leading)
                Image(systemName: "cat.fill")
                    .resizable()
                    .frame(width: 300, height: 300)
                    .foregroundStyle(.orange)
                    .padding()
                Image(systemName: "map")
                    .resizable()
                    .frame(width: 300, height: 300)
                    .foregroundStyle(.green)
                    .padding()
            }
            .padding()
        }
        .navigationTitle("Cat name")
    }
}

#Preview {
    NavigationStack {
        CatDetailView()
    }
}
