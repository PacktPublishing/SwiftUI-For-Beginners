import SwiftUI

struct CatDetailView: View {
    var body: some View {
        ScrollView {
            VStack {
                Text("8 April 2026")
                    .font(.title2)
                    .frame(maxWidth: .infinity, alignment: .trailing)
                RoundedRectangle(cornerRadius: 8)
                    .frame(width: 252, height: 44)
                    .foregroundStyle(.blue)
                Text("Cat description")
                    .font(.title2)
                    .frame(maxWidth: .infinity, alignment: .leading)
                Image(systemName: "cat.fill")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 300, height: 300)
                    .foregroundStyle(.orange)
                Image(systemName: "map")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 300, height: 300)
                    .foregroundStyle(.green)
            }
            .padding()
        }
            .navigationTitle("Cat name")
    }
}

#Preview {
    NavigationStack {
        CatDetailView()
    }
}
