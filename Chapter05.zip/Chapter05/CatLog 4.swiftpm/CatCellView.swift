import SwiftUI

struct CatCellView: View {
    var body: some View {
        HStack {
            Image(systemName: "cat.fill")
                .resizable()
                .frame(width: 90, height: 90)
                .padding()
            VStack {
                Text("Date")
                    .font(.largeTitle)
                    .frame(maxWidth: .infinity, alignment: .leading)
                Text("Cat name")
                    .lineLimit(2)
                    .font(.title2)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
    }
}

#Preview {
    CatCellView()
}
