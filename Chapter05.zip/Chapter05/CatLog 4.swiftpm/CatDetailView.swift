import SwiftUI

struct CatDetailView: View {
    var body: some View {
        ScrollView {
            VStack {
                Text("8 April 2026")
                    .font(.title)
                    .frame(maxWidth: .infinity, alignment: .trailing)
                RoundedRectangle(cornerRadius: 8)
                    .frame(width: 252, height: 44)
                    .foregroundStyle(.blue)
                Text("Cat description")
                    .font(.title2)
                    .frame(maxWidth: .infinity, alignment: .leading)
                Image(systemName: "cat.fill")
                    .resizable()
                    .frame(width: 300, height: 300)
                    .foregroundStyle(.orange)
                    .padding()
                Image(systemName: "map")
                    .resizable()
                    .frame(width: 300, height: 300)
                    .foregroundStyle(.green)
                    .padding()
            }
        }
            .navigationTitle("Cat Detail View")
    }
}

#Preview {
    NavigationStack {
        CatDetailView()
    }
}
