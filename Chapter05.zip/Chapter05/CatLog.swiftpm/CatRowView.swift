import SwiftUI

struct CatRowView: View {
    var body: some View {
        HStack {
            Image(systemName: "cat.fill")
                .resizable()
                .scaledToFit()
                .frame(width: 90, height: 90)
            VStack {
                Text("Cat name")
                    .font(.largeTitle)
                    .frame(maxWidth: .infinity, alignment: .leading)
                Text("Cat description")
                    .lineLimit(2, reservesSpace: true)
                    .font(.title2)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
    }
}

#Preview {
    CatRowView()
}
