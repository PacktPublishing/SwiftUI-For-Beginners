import SwiftUI

struct CatsView: View {
    @State private var showAddCatView = false
    var body: some View {
        NavigationStack {
            List {
                NavigationLink(destination: CatDetailView()) {
                    CatRowView()
                }
                NavigationLink(destination: CatDetailView()) {
                    CatRowView()
                }
                NavigationLink(destination: CatDetailView()) {
                    CatRowView()
                }
            }
            .navigationTitle("Cats")
            .toolbar {
                ToolbarItem(placement: .primaryAction) {
                    Button("Add", systemImage: "plus") {
                        showAddCatView = true
                    }
                    .sheet(isPresented: $showAddCatView) {
                        AddNewCatView()
                    }
                }
            }
        }
    }
}

#Preview {
    CatsView()
}
