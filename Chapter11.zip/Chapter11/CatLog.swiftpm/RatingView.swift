import SwiftUI

struct RatingView: View {
    @Binding var rating: Int 
    let maxRating = 5
    let emptyStar = Image(systemName: "star")
    let filledStar = Image(systemName: "star.fill")
    var body: some View {
        HStack(spacing: 8) {
            ForEach(1..<maxRating + 1, id: \.self) {
                number in 
                Button {
                    rating = number
                } label: {
                    image(for: number)
                        .resizable()
                        .frame(width: 44, height: 44)
                        .foregroundStyle(.blue)
                }
            }
        }
    }
    
    func image(for number: Int) -> Image {
        if number > rating {
            emptyStar
        } else {
            filledStar
        }
    }
}

#Preview {
    RatingView(rating: .constant(3))
}
