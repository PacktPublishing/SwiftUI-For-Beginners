import SwiftUI
import CoreLocation
import SwiftData
import PhotosUI

struct AddNewCatView: View {
    @State private var catName = ""
    @State private var catDescription = ""
    @State private var rating = 0
    @State private var toggleText = "Get Location"
    @State private var toggleValue = false
    private let locationManager = CLLocationManager()
    @State private var locationTask: Task<Void, Error>?
    @State private var currentLocation: CLLocation?
    @State private var isShowingLocationNotFound = false
    @State private var locationNotFoundReason = ""
    @State private var photoData: Data?
    @State private var newPhoto: PhotosPickerItem?
    @Environment(\.dismiss) private var dismiss
    @Environment(DataContainer.self) private var dataContainer
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .center) {
                    RatingView(rating: $rating)
                    Toggle(toggleText, isOn: $toggleValue)
                        .onChange(of: toggleValue) {
                            if toggleValue {
                                toggleText = "Getting location..."
                                fetchUserLocation()
                            } else {
                                currentLocation = nil
                                toggleText = "Get Location"
                                locationTask?.cancel()
                            }
                        }
                        .alert(locationNotFoundReason, isPresented: $isShowingLocationNotFound) {
                            Button("OK") {
                                toggleValue = false
                                isShowingLocationNotFound = false
                            }
                        }
                    TextField("Cat name", text: $catName)
                        .font(.largeTitle)
                    TextField("Cat description", text: $catDescription, axis: .vertical)
                        .font(.title2)
                        .multilineTextAlignment(.leading)
                        .lineLimit(5...Int.max)
                    photosPicker
                }
                .padding()
            }
                .navigationTitle("Add New Cat")
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) {
                        Button("Cancel", systemImage: "xmark") {
                            dismiss()
                        }
                    }
                    ToolbarItem(placement: .confirmationAction) {
                        Button("Save", systemImage: "checkmark") {
                            let newCat = Cat(rating: rating, catName: catName, catDescription: catDescription, photoData: photoData, latitude: currentLocation?.coordinate.latitude, longitude: currentLocation?.coordinate.longitude)
                            dataContainer.context.insert(newCat)
                            do {
                                try dataContainer.context.save()
                            } catch {
                                print("Error: \(error.localizedDescription)")
                            }
                            dismiss()
                        }
                        .disabled(catName.isEmpty || catDescription.isEmpty)
                    }
                }
        }
    }
    
    private func fetchUserLocation() {
        locationManager.requestWhenInUseAuthorization()
        locationTask = Task {
            for try await update in CLLocationUpdate.liveUpdates() {
                if let location = update.location {
                    updateCurrentLocation(location)
                } else if update.authorizationDenied {
                    locationNotFoundReason = "Authorization Denied"
                    isShowingLocationNotFound = true
                } else if update.locationUnavailable {
                    locationNotFoundReason = "Location Unavailable"
                    isShowingLocationNotFound = true
                }
            }
        }
    }
    
    private func updateCurrentLocation(_ location: CLLocation) {
        let interval = location.timestamp.timeIntervalSinceNow
        if abs(interval) < 30 {
            locationTask?.cancel()
            toggleText = "Done"
            let lat = location.coordinate.latitude
            let long = location.coordinate.longitude
            currentLocation = CLLocation(latitude: lat, longitude: long)
        }
    }
    
    private var photosPicker: some View {
        PhotosPicker(selection: $newPhoto, matching: .images) {
            Group {
                if let photoData, let uiImage = UIImage(data: photoData) {
                    Image(uiImage: uiImage)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 300, height: 300)
                } else {
                    Image(systemName: "photo.badge.plus.fill")
                        .font(.largeTitle)
                        .frame(width: 300, height: 300)
                        .background(Color.gray)
                }
            }
            .clipShape(RoundedRectangle(cornerRadius: 16))
        }
        .onChange(of: newPhoto) {
            guard let newPhoto else { return }
            Task {
                guard let newPhotoData = try await newPhoto.loadTransferable(type: Data.self), let fullsizePhoto = UIImage(data: newPhotoData), let smallerPhoto = fullsizePhoto.preparingThumbnail(of: CGSize(width: 300, height: 300)) else { return}
                photoData = smallerPhoto.pngData()
            }
        }
    }
    
}

