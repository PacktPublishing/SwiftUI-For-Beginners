import SwiftUI
import SwiftData

@Model
class Cat {
    var date: Date
    var rating: Int
    var catName: String
    var catDescription: String
    @Attribute(.externalStorage) var photoData: Data?
    var latitude: Double?
    var longitude: Double?
    var photo: UIImage? {
        photoData.flatMap {
            UIImage(data: $0)
        }
    }
    
    init(rating: Int, catName: String, catDescription: String, photoData: Data? = nil, latitude: Double? = nil, longitude: Double? = nil) {
        self.date = Date()
        self.rating = rating
        self.catName = catName
        self.catDescription = catDescription
        self.photoData = photoData
        self.latitude = latitude
        self.longitude = longitude
    }
}
