import SwiftUI
import SwiftData

struct CatsView: View {
    @State private var showAddCatView = false
    @Query(sort: \Cat.date)
    private var cats: [Cat]
    @Environment(DataContainer.self) private var dataContainer
    var body: some View {
        NavigationStack {
            List {
                ForEach(cats) { cat in
                    NavigationLink(destination: CatDetailView(selectedCat: cat)) {
                        CatCellView(cat: cat)
                    }
                }
                .onDelete { indexSet in
                    for index in indexSet {
                        dataContainer.context.delete(cats[index])
                        try? dataContainer.context.save()
                    }
                }
            }
            .navigationTitle("Cats")
            .toolbar {
                ToolbarItem(placement: .primaryAction) {
                    Button("Add", systemImage: "plus") {
                        showAddCatView = true
                    }
                    .sheet(isPresented: $showAddCatView) {
                        AddNewCatView()
                    }
                }
            }
        }
    }
}

#Preview {
    CatsView()
}
