import SwiftUI

struct CatDetailView: View {
    var body: some View {
        Text("Cat Detail View")
            .navigationTitle("Cat Detail")
    }
}

#Preview {
    NavigationStack {
        CatDetailView()
    }
}
