import SwiftUI

struct CatDetailView: View {
    var body: some View {
        Text("Cat Detail View")
            .navigationTitle("Cat Detail View")
    }
}

#Preview {
    NavigationStack {
        CatDetailView()
    }
}
