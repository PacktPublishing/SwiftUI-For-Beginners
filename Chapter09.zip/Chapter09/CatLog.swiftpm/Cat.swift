import SwiftUI
import SwiftData

@Model
class Cat {
    var date: Date
    var rating: Int
    var catName: String
    var catDescription: String
    var photoData: Data?
    var latitude: Double?
    var longitude: Double?
    var photo: UIImage? {
        photoData.flatMap {
            UIImage(data: $0)
        }
    }
    
    init(rating: Int, catName: String, catDescription: String, photoData: Data? = nil, latitude: Double? = nil, longitude: Double? = nil) {
        self.date = Date()
        self.rating = rating
        self.catName = catName
        self.catDescription = catDescription
        self.photoData = photoData
        self.latitude = latitude
        self.longitude = longitude
    }
}

// Sample data
extension Cat {
    static let sampleCat = sampleCatData[0]
    static let sampleCatData = [
        Cat(rating: 5, catName: "Thor", catDescription: "Orange tabby", photoData: UIImage(systemName: "cat")?.pngData()),
        Cat(rating: 4, catName: "Loki", catDescription: "Tuxedo cat", photoData: UIImage(systemName: "cat.fill")?.pngData()),
        Cat(rating: 3, catName: "Lokitu", catDescription: "Hungry cat", photoData: UIImage(systemName: "cat.fill")?.pngData()),
    ]
}
